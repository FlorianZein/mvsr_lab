# mvsrlab > dataset version3
https://universe.roboflow.com/mvsrlab-5y0ki/mvsrlab

Provided by a Roboflow user
License: CC BY 4.0

